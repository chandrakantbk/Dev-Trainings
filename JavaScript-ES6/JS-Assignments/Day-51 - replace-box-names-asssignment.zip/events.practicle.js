function fun() {
    var heading = document.getElementsByTagName('h1')[0];

    heading.innerHTML = "I have Learned JS Events"
}

function showMessage() {

}


function updateBox() {

}